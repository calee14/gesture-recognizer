import GestureRecognizer
import threading
rec = GestureRecognizer.GestureRecognizer()
rec.recognize_fist()
