# gesture-recognizer
This is a python package designed to recognize basic hand gestures. This project is for SMHacks II.
