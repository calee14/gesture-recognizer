# gesture-recognizer
This is a python package designed to recognize basic hand gestures. This project people we want to experiment with gesture recognition.

# Note to developer 
When uploading to pypi if there is an error saying that some files already exist run the command below.
```
--skip-existing
```